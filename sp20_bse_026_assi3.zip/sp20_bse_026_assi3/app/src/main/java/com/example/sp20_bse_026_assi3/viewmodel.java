package com.example.sp20_bse_026_assi3;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class viewmodel extends ViewModel {
    MutableLiveData<Integer> path=new MutableLiveData<>();
    String name;
}