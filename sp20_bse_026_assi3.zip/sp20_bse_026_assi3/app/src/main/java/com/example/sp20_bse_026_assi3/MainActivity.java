package com.example.sp20_bse_026_assi3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.res.Configuration;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {

    viewmodel viewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //check to see if screen is in landscape
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            viewModel=new ViewModelProvider(this).get(viewmodel.class);
        }

    }

}//end class