package com.example.sp20_bse_026_assi3;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.VideoView;

public class player extends Fragment {

    VideoView videoview;
    viewmodel vm;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_player, container, false);
        MediaController mc= new MediaController(getActivity());
        videoview = (VideoView) view.findViewById(R.id.videoView);
        videoview.setMediaController(mc);
       // Uri uri = Uri.parse("android.resource://"+ getActivity().getPackageName()+"/"+R.raw.tupac);

      // videoview.setVideoURI(Uri.parse(this.uri));
        // videoview.start();
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        vm=new ViewModelProvider((MainActivity)context).get(viewmodel.class);
    }

    @Override
    public void onResume() {
        super.onResume();
        vm.path.observe(getViewLifecycleOwner(), new Observer<Integer>() {
            @Override
            public void onChanged(Integer integer) {
                videoview.setVideoPath(vm.name);
                videoview.start();
            }
        });
    }
    public void playVideo(String uri){
        videoview.setVideoURI(Uri.parse(uri));
        videoview.start();
    }
}