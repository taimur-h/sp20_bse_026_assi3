package com.example.sp20_bse_026_assi3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

public class RecviewAdapter extends RecyclerView.Adapter<RecviewAdapter.RecviewViewHolder> {
    private String[] dataset;

    public RecviewAdapter(String[] dataset){
        this.dataset = dataset;
    }

    @NonNull
    @Override
    public RecviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RelativeLayout itemLayout = (RelativeLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.list_recycler_view,parent,false);
        RecviewViewHolder recviewViewHolder = new RecviewViewHolder(itemLayout);
        return recviewViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecviewViewHolder holder, int position) {
        holder.textView.setText(dataset[position]);
    }

    @Override
    public int getItemCount() {
        return dataset.length;
    }

    public class RecviewViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;
        viewmodel viewModl;
        public RecviewViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            viewModl=new ViewModelProvider((MainActivity)itemView.getContext()).get(viewmodel.class);
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        viewModl.path.setValue(getAdapterPosition());
                }
            });
        }

    }
}

