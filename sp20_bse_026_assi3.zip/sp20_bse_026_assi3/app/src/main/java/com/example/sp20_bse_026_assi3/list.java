package com.example.sp20_bse_026_assi3;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.Observer;

public class list extends Fragment {
    RecyclerView recyclerView;
    String[] datset;
    viewmodel vm;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_list, container, false);
        recyclerView = view.findViewById(R.id.recview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        String rs = "android.resource://"+ getActivity().getPackageName()+"/";
        String[] datset ={
                rs+R.raw.tupac,
                rs+R.raw.bable,
                rs+R.raw.music
        };

        RecviewAdapter recviewAdapter = new RecviewAdapter(datset);
        recyclerView.setAdapter(recviewAdapter);
        vm.path.observe(getViewLifecycleOwner(), new Observer<Integer>() {

            @Override
            public void onChanged(Integer integer) {
                vm.name = datset[integer];
            }
        });
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        vm = new ViewModelProvider((MainActivity) context).get(viewmodel.class);
    }
}